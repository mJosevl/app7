package com.example.mjosevl20240512

import SessionManager
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity(), FetchBitcoinPriceTask.OnFetchCompleteListener {

    private lateinit var bitcoinPriceTextView: TextView
    private lateinit var welcomeTextView: TextView
    private lateinit var sessionManager: SessionManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        sessionManager = SessionManager(this)

        bitcoinPriceTextView = findViewById(R.id.bitcoinPriceTextView)
        welcomeTextView = findViewById(R.id.welcomeTextView)
        val updateButton = findViewById<Button>(R.id.updateButton)
        val logoutButton = findViewById<Button>(R.id.logoutButton)

        welcomeTextView.text = "Bienvenido: ${sessionManager.getUsername()}"

        updateButton.setOnClickListener {
            updateBitcoinPrice()
        }

        logoutButton.setOnClickListener {
            sessionManager.setLogin(false)
            sessionManager.setUsername("")
            val intent = Intent(this, LoginActivity::class.java)
            startActivity(intent)
            finish()
        }
    }

    private fun updateBitcoinPrice() {
        FetchBitcoinPriceTask(this).execute()
    }

    override fun onFetchComplete(price: Double?) {
        if (price != null) {
            bitcoinPriceTextView.text = "Precio Bitcoin: $price"
        } else {
            Toast.makeText(this, "Error al obtener datos del precio del Bitcoin", Toast.LENGTH_SHORT).show()
        }
    }
}
