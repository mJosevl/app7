package com.example.mjosevl20240512


import android.os.AsyncTask
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import org.json.JSONObject

class FetchBitcoinPriceTask(private val listener: OnFetchCompleteListener) : AsyncTask<Void, Void, Double?>() {

    interface OnFetchCompleteListener {
        fun onFetchComplete(price: Double?)
    }

    override fun doInBackground(vararg params: Void?): Double? {
        val apiUrl = "https://mindicador.cl/api/bitcoin"
        var price: Double? = null

        try {
            val url = URL(apiUrl)
            val connection = url.openConnection() as HttpURLConnection
            connection.requestMethod = "GET"

            val responseCode = connection.responseCode
            if (responseCode == HttpURLConnection.HTTP_OK) {
                val inputStream = connection.inputStream
                val bufferedReader = BufferedReader(InputStreamReader(inputStream))
                val response = StringBuilder()
                bufferedReader.useLines { lines -> lines.forEach { response.append(it) } }

                val jsonResponse = JSONObject(response.toString())
                val serieArray = jsonResponse.getJSONArray("serie")
                if (serieArray.length() > 0) {
                    val latestEntry = serieArray.getJSONObject(0)
                    price = latestEntry.getDouble("valor")
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        return price
    }

    override fun onPostExecute(result: Double?) {
        super.onPostExecute(result)
        listener.onFetchComplete(result)
    }
}
