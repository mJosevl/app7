package com.example.mjosevl20240512.data


data class Usuario(
    val username: String,

    val password: String,

    val nombreCompleto: String
)
