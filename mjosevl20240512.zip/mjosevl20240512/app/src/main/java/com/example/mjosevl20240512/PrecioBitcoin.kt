package com.example.mjosevl20240512

data class PrecioBitcoin(
    val codigo: String,
    val nombre: String,
    val unidadMedida: String,
    val fecha: String,
    val valor: Float
)
